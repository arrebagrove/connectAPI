﻿using System;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Security.Authentication;
using System.Collections;

//Add MySql Library
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace FxstarServerFX
{
        public class server
        {
            /// <summary>
            /// Mysql connection part
            /// </summary>
            /// <returns></returns>
            /// 
            // Mysql COnnection variables             
            public static string mhost = "localhost";
            public static string mdatabase = "fxstareu";
            public static string muser = "root";
            public static string mpass = "toor";
            public static string con = "SERVER=" + mhost + ";" + "DATABASE=" + mdatabase + ";" + "UID=" + muser + ";" + "PASSWORD=" + mpass + ";";
            //public static MySqlConnection connection = new MySqlConnection(con);

        public static string SelectOpen()
        {
            MySqlConnection connection = new MySqlConnection(con);
            connection.Open();
            string query = "SELECT * FROM account_6871192 LIMIT 5";

            //Create a list to store the result
            List<string>[] list = new List<string>[9];
            string[][] arr = new string[20][];
            for (int x = 0; x < arr.Length; x++)
            {
                arr[x] = new string[8];
            }

            list[0] = new List<string>();
            list[1] = new List<string>();
            list[2] = new List<string>();
            list[3] = new List<string>();
            list[4] = new List<string>();
            list[5] = new List<string>();
            list[6] = new List<string>();
            list[7] = new List<string>();
            list[8] = new List<string>();

            MySqlCommand cmd = new MySqlCommand(query, connection);
            MySqlDataReader dataReader = cmd.ExecuteReader();

            int nr = 0;
            while (dataReader.Read())
            {
                // Console.WriteLine("\t{0}\t{1}", reader.GetInt32(0), reader.GetString(1));
                /// SET POSITION HERE DONT INSERT IN ARRAY
                /// create file with position or check is exist position with label in history or open positions

                arr[nr][0] = "" + dataReader["id"];
                arr[nr][1] = "" + dataReader["symbol"];
                arr[nr][2] = "" + dataReader["volume"];
                arr[nr][3] = "" + dataReader["type"];
                arr[nr][4] = "" + dataReader["opent"];
                arr[nr][5] = "" + dataReader["openp"];
                arr[nr][6] = "" + dataReader["sl"];
                arr[nr][7] = "" + dataReader["tp"];

                nr++;

                //Print(dataReader["id"]);
                list[0].Add(dataReader["id"] + "");
                list[1].Add(dataReader["symbol"] + "");
                list[2].Add(dataReader["volume"] + "");
                list[3].Add(dataReader["type"] + "");
                list[4].Add(dataReader["opent"] + "");
                list[5].Add(dataReader["sl"] + "");
                list[6].Add(dataReader["tp"] + "");
                list[7].Add(dataReader["time"] + "");
                list[8].Add(dataReader["account"] + "");
            }
            dataReader.Close();
            connection.Close();

            string out2 = "";
            out2 = JsonConvert.SerializeObject(list);
            return out2;
        }


        //Select statement
        //public List<string>[] Select()
        public static string Select()
            {
                MySqlConnection connection = new MySqlConnection(con);
                connection.Open();
                string query = "SELECT * FROM account_6871192 LIMIT 5";
                //Create a list to store the result
                List<string>[] list = new List<string>[3];
                list[0] = new List<string>();
                list[1] = new List<string>();
                list[2] = new List<string>();

                //Create Command            
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();

                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    list[0].Add(dataReader["accountid"] + "");
                    list[1].Add(dataReader["balance"] + "");
                    list[2].Add(dataReader["equity"] + "");
                }

                //close Data Reader and connection
                dataReader.Close();
                connection.Close();

                string out1 = "";

                out1 = JsonConvert.SerializeObject(list);
                /*
                foreach (List<string> element in list)
                {
                    //Print("ELEMENT " + element);
                    string line = string.Join(",", element.ToArray());
                    //Print("POZYCJA ============================= " + line);
                    //Print(element.ElementAt(0));
                    foreach (string pos in element)
                    {
                        //Console.WriteLine(pos);
                        out1 = out1 + "|" + pos;
                    }
                }
                */

                //return list to be displayed
                //return list;
                return out1;
            }

            /// <summary>
            /// Socket part
            /// </summary>
            // Socket
            public static ArrayList arrSocket = new ArrayList();

            private string positions = "";
            // Declare a two dimensional array 
            // users allowed 10
            private static int maxSlots = 11;
            private string[,] posArray = new string[maxSlots + 1, 1];
            X509Certificate serverCertificate = new X509Certificate2("ssl.p12", "XO8zB3Dh18T");

            ManualResetEvent tcpClientConnected = new ManualResetEvent(false);

            static void DisplayCertificateInformation(SslStream stream)
            {
                Console.WriteLine("Certificate revocation list checked: {0}", stream.CheckCertRevocationStatus);

                X509Certificate localCertificate = stream.LocalCertificate;
                if (stream.LocalCertificate != null)
                {
                    Console.WriteLine("Local cert was issued to {0} and is valid from {1} until {2}.",
                        localCertificate.Subject,
                        localCertificate.GetEffectiveDateString(),
                        localCertificate.GetExpirationDateString());
                }
                else
                {
                    Console.WriteLine("Local certificate is null.");
                }
                // Display the properties of the client's certificate.
                X509Certificate remoteCertificate = stream.RemoteCertificate;
                if (stream.RemoteCertificate != null)
                {
                    Console.WriteLine("Remote cert was issued to {0} and is valid from {1} until {2}.",
                        remoteCertificate.Subject,
                        remoteCertificate.GetEffectiveDateString(),
                        remoteCertificate.GetExpirationDateString());
                }
                else
                {
                    Console.WriteLine("Remote certificate is null.");
                }
            }

            static string ReadMessageTrader(string msg)
            {
                // User password and which account copy
                string user = "";
                string pass = "";
                string copyid = "";
                string cmd = "";
                string pos = "";
                try
                {
                    string[] FXmsg = Regex.Split(msg, "#");
                    user = FXmsg[1];
                    pass = FXmsg[2];
                    copyid = FXmsg[3];
                    cmd = FXmsg[4];
                    if (cmd == "GETOPEN")
                    {
                        pos = SelectOpen();
                    }else {
                        pos = SelectOpen();
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }

                return pos;
            }

            static string ReadMessage(SslStream sslStream)
            {
                // Read the  message sent by the client. 
                // The client signals the end of the message using the 
                // "<EOF>" marker.
                byte[] buffer = new byte[2048];
                StringBuilder messageData = new StringBuilder();
                int bytes = -1;
                do
                {
                    // Read the client's test message.
                    bytes = sslStream.Read(buffer, 0, buffer.Length);

                    // Use Decoder class to convert from bytes to UTF8 
                    // in case a character spans two buffers.
                    Decoder decoder = Encoding.UTF8.GetDecoder();
                    char[] chars = new char[decoder.GetCharCount(buffer, 0, bytes)];
                    decoder.GetChars(buffer, 0, bytes, chars, 0);
                    messageData.Append(chars);
                    // Check for EOF or an empty message. 
                    if (messageData.ToString().IndexOf("<EOF>") != -1)
                    {
                        break;
                    }
                } while (bytes != 0);

                return ReadMessageTrader(messageData.ToString());
                //return messageData.ToString();
            }


            void ProcessIncomingData(object obj)
            {
                SslStream sslStream = (SslStream)obj;
                try
                {
                    //
                    // Set timeouts for the read and write to 5 seconds.
                    sslStream.ReadTimeout = 5000;
                    sslStream.WriteTimeout = 5000;
                    // Read a message from the client.   
                    Console.WriteLine("Waiting for client message...");
                    string messageData = ReadMessage(sslStream);
                    Console.WriteLine("Received: {0}", messageData);
                    //Select();
                    // Write a message to the client. 
                    // byte[] message = Encoding.UTF8.GetBytes("Hello from the server." + Select()  + "<EOF>");
                    byte[] message = Encoding.UTF8.GetBytes("Hello from the server." + messageData + "<EOF>");
                    //Console.WriteLine("Sending hello message.");                
                    sslStream.Write(message);
                    sslStream.Flush();

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }

            }

            void ProcessIncomingConnection(IAsyncResult ar)
            {
                TcpListener listener = (TcpListener)ar.AsyncState;
                TcpClient client = listener.EndAcceptTcpClient(ar);
                SslStream sslStream = new SslStream(client.GetStream(), false);
                try
                {

                    sslStream.AuthenticateAsServer(serverCertificate, false, SslProtocols.Tls, true);
                    //DisplayCertificateInformation(sslStream);
                    // remote ip address
                    Console.Write(((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString());
                }
                catch (Exception e)
                {
                    Console.WriteLine("Client no ssl" + client);
                    client.Close();
                }

                ThreadPool.QueueUserWorkItem(ProcessIncomingData, sslStream);
                tcpClientConnected.Set();
                //Console.Write(((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString());

                /*
                arrSocket.Add(sslStream);
                foreach (object obj in arrSocket) // Repeat for each connected client (socket held in a dynamic array)
                {
                    try
                    {
                        SslStream socket = (SslStream)obj;
                        byte[] message = Encoding.UTF8.GetBytes("Nowy użytkownik zalogowany.<EOF>");
                        Console.WriteLine("Sending message to " + client.ToString());
                        socket.WriteAsync(message, 0, message.Length);
                        socket.Flush();
                    }
                    catch (Exception aa)
                    {
                        Console.WriteLine(aa);
                    }
                }
                */

            }

            public void start()
            {
                IPEndPoint endpoint = new IPEndPoint(IPAddress.Parse("92.222.7.98"), 5555);
                TcpListener listener = new TcpListener(endpoint);
                listener.Start();

                while (true)
                {
                    tcpClientConnected.Reset();
                    listener.BeginAcceptTcpClient(new AsyncCallback(ProcessIncomingConnection), listener);
                    tcpClientConnected.WaitOne();
                }
            }
        }

        class Program
        {
            static void Main(string[] args)
            {

                Console.WriteLine("Multi user server. Recive save and send data to clients max 10 accounts.");
                //DateTime.Now.ToLongTimeString()
                Console.WriteLine(DateTime.Now + " Waiting for connections....");
                try
                {
                    server s = new server();
                    s.start();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
            }
        }
    }
