﻿SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `FxstarTrader` DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;
USE FxstarTrader;

CREATE TABLE IF NOT EXISTS `account_1`(time datetime, accountid int, balance float(10,2),equity float(10,2),margin float(10,2),freemargin float(10,2), currency varchar(20), leverage int, UNIQUE KEY `time` (`time`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `OpenSignal_1` (  `id` varchar(250) DEFAULT NULL,  `symbol` varchar(250) DEFAULT '0',  `volume` float DEFAULT '0',  `type` varchar(250) DEFAULT '0',  `opent` datetime,  `openp` float(25,6) DEFAULT '0',  `sl` float(25,6) DEFAULT '0',  `tp` float(25,6) DEFAULT '0',  `profit` float(55,2) DEFAULT '0',    `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  `account` varchar(250) DEFAULT '0',  `comment` text,  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `CloseSignal_1` (  `id` varchar(250) DEFAULT NULL,  `closet` datetime,  `closep` float(25,6) DEFAULT '0',  `profit` float(55,2) DEFAULT '0',  `pips` float(25,2) DEFAULT '0',  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  `account` varchar(250) DEFAULT '0',  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) COLLATE utf8_general_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_general_ci NOT NULL,
  `pass` varchar(32) COLLATE utf8_general_ci NOT NULL,
  `about` varchar(250) COLLATE utf8_general_ci DEFAULT NULL,
  `dofb` int(21) NOT NULL DEFAULT '1',
  `sex` char(1) COLLATE utf8_general_ci NOT NULL DEFAULT '1',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` text COLLATE utf8_general_ci,
  `active` char(1) COLLATE utf8_general_ci DEFAULT '1',
  `vip` char(1) COLLATE utf8_general_ci NOT NULL DEFAULT '0',
  `adres` varchar(100) COLLATE utf8_general_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8_general_ci DEFAULT NULL,
  `mail` varchar(250) COLLATE utf8_general_ci DEFAULT NULL,
  `www` varchar(250) COLLATE utf8_general_ci DEFAULT NULL,
  `branza` int(21) NOT NULL DEFAULT '0',
  `lubisz` int(21) NOT NULL DEFAULT '0',
  `lubia` int(21) NOT NULL DEFAULT '0',
  `code` varchar(32) COLLATE utf8_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

DROP TABLE IF EXISTS `znajomi`;
CREATE TABLE IF NOT EXISTS `znajomi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `zid` bigint(20) NOT NULL,
  `ztyp` int NOT NULL,
  `unique` varchar(250),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique` (`uid`,`zid`)  
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;