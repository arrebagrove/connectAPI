﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.IO;


namespace Counter
{
    class Program
    {       

        static void Main(string[] args)
        {
            StartTimer();
            Console.ReadKey();

        }

        private static void StartTimer()
        {
            Timer t = new Timer();
            t.Enabled = true;
            t.Interval = 1000;
            t.Elapsed += t_Elapsed;
        }

        static void t_Elapsed(object sender, ElapsedEventArgs e)
        {
            string path = Directory.GetCurrentDirectory();
            String dir = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            Console.WriteLine(dir);
            try
            {
                File.AppendAllText(dir + @"\service.log", "Time " + DateTime.UtcNow.ToString()+"\r\n");
                Console.WriteLine(dir + @"\service.log");
            }
            catch (Exception ee)
            {
                Console.WriteLine(ee.ToString());
                File.AppendAllText(dir + @"\service.log", "Time " + ee.ToString() + " " + DateTime.UtcNow.ToString());
            }
        }
    }
}
